﻿<!-- 제목명 -->

<table style="width:100%;">
	<tr style="height:1px;">
		<td style="width:25%; background-color:#fff;">
		</td>
		<td style="width:30%; background-color:#fff;">
		</td>
		<td style="width:45%; background-color:#fff;">
		</td>
	</tr>
	
	<tr style="height:40px;">
		<td colspan="2" class="header_background">
			<div class="title">Dodo's World</div>
		</td>
		<td class="header_background">
			
		</td>
	</tr>
	
	<tr style="height:1px;">
		<td style="width:25%; background-color:#FE2E64;">
		</td>
		<td colspan="2" style="width:45%; background-color:#81BEF7;">
		</td>
	</tr>
</table>

<!-- 바디(Body) -->
<table style="width:100%;">
	<tr>
		<td style="width:20%; vertical-align:top;">
			<ul class="menu">
				<!-- 홈(Home) -->
				<li>
					<div class="menu_txt">
						<b>홈(Home)</b>
					</div>
					<ul>
						<li>
							<div class="menu_txt">
								<a href="index.php/homepage/about" target="main">소개(Introduce)</a>
							</div>
						</li>
						<li>
							<div class="menu_txt">
								<a href="index.php/homepage/history" target="main">연혁(History)</a>
							</div>
						</li>
					</ul>
				</li>
				<!-- 게시판 -->
				<li>
					<div class="menu_txt">
						<b>게시판(Bulletin board)</b>
					</div>
					<ul>
						<li>
							<div class="menu_txt">
								<a href="index.php/board/rabbit2me/list" target="main">
									공지사항(Notice)
								</a>
							</div>
						</li>
						<li>
							<div class="menu_txt">
								<a href="index.php/board/rabbit2me/list" target="main">
									이야기(Story)
								</a>
							</div>
						</li>
						<li>
							<div class="menu_txt">
								<a href="index.php/board/rabbit2me/list" target="main">
									
								</a>
							</div>
						</li>
					</ul>
				</li>
			</ul>
		</td>
		<td>
			
			<iframe name="main" src="index.php/homepage/notice" style="width:100%;height:700px; border:none;"></iframe>
		</td>
	</tr>
</table>