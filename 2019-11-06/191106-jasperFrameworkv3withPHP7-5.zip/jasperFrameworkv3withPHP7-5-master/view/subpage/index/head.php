﻿<!DOCTYPE html>
<html lang="ko">
<head>
<title><?php echo $title;?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo $font_dir; ?>nanumbarungothicsubset.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $skin_dir; ?>css/jasper_home.css">	
	<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bPopup/0.11.0/jquery.bpopup.js"></script>
	<script src="<?php echo $skin_dir; ?>js/mainLayer.js"></script>

</head>
<body>