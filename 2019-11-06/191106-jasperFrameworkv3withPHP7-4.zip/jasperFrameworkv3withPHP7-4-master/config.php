<?php

/*
 * Subject: PHP 7 - Config.php
 * Created Date: 2019-10-30
 * Author: Dodo (rabbit.white@daum.net)
 * Description:
 *
 */

// MySQL 계정

$MYSQL_HOSTNAME = "localhost";
$MYSQL_USERNAME = "root";
$MYSQL_PASSWORD = "1234";
$MYSQL_DATABASE = "rabbit2me";
$MYSQL_PORT = "3306";
$MYSQL_CHARSET = "utf8";

/*
$MYSQL_HOSTNAME = "localhost";
$MYSQL_USERNAME = "tiger";
$MYSQL_PASSWORD = "1234";
$MYSQL_DATABASE = "tiger";
$MYSQL_PORT = "3306";
$MYSQL_CHARSET = "utf8";
*/

// 경로 설정
$HOME_ROOT = "C:/Apache24/htdocs";
$HOME_DIRECTORIES = '/MyHomepage';
#$HOME_ROOT = "/host/home2/rabbit2me/html";
#$HOME_DIRECTORIES = '/beta';


/*
$HOME_ROOT = "/home/rabbit2me/public_html";
$HOME_DIRECTORIES = '';

*/

?>