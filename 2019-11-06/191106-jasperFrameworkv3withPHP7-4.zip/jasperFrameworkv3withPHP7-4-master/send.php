<?php


?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>예제</title>
</head>
<body>

<form action="index.php/board" method="post">
	<p><input type="text" name="title"></p>
	<p><input type="submit" value="전송"></p>

</form>

</body>
</html>