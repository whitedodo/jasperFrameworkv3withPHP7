<!DOCTYPE html>
<html lang="ko">
<head>
	<title><?php echo $title; ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo $font_dir; ?>nanumbarungothicsubset.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $skin_dir; ?>css/main.css">
	<script src="<?php echo $skin_dir; ?>js/script.js"></script>

</head>