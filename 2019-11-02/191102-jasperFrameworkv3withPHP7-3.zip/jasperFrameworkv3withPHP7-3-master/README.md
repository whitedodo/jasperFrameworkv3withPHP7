## [jasperFramework v3 with PHP7.3 and MariaDB 10.2]

#### 작성자 소개(About the author)
> ##### 1. Dodo (rabbit.white@daum.net)
> ##### 2. Created by: 2019-11-03
> ##### 3. Description: 
> ###### 3-1. 2019-10-28 ~ 2019-11-01 (게시물 보기, 조회, RSS 피더 지원 / View Posts, View, RSS Feeder Support)
> ###### 3-2. 2019-11-02 (댓글 기능 추가 / Added comment function)
> ###### 3-3. 2019-11-03 (보호글 기능 추가 / Added protected Article function)
> ##### 4. License: GNU License v3

#### 빌드(Build)
> ##### 1. Apache 2.4, PHP 7.3 환경에 넣어서 사용하면 된다.(Can be used in Apache 2.4, PHP 7.3 environment.)

#### Quick Start(쉬운 시작)
> ##### 1. 191101 JasperFramework V3 with PHP 7 and MariaDB -1부-, 2019-11-01, https://youtu.be/sDjjLt-mY1s 
> ##### 2. 191101 JasperFramework V3 with PHP 7 and MariaDB -2부-, 2019-11-01, https://youtu.be/MY-b5vkXD18
> ##### 3. 191102 JasperFramework V3 with PHP 7 and MariaDB -3부-, 2019-11-02, https://youtu.be/f_EUoDa0fF4

> ###### 보충 링크(Supplementary links): http://localhost/유저디렉토리/index.php/board/rabbit2me/list[write,modify,remove,rss]
> ###### 보충 링크(Supplementary links): http://localhost/유저디렉토리/index.php/login_cookie
> ###### 보충 링크(Supplementary links): http://localhost/유저디렉토리/index.php/login_session
> ###### 보충 링크(Supplementary links): http://localhost/유저디렉토리/cookie_login.php
> ###### 보충 링크(Supplementary links): http://localhost/유저디렉토리/session_login.php

#### 시연(Practice Site)
(Internet Explorer: O, Chrome: O, Mozilla Firefox: O, Microsoft Edge: O)
